# Pixie-log
My personal learning log of coding and building projects.
